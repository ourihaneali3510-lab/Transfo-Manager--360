package com.transfomanager360

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class Wilaya(val code: Int, val fr: String, val ar: String) {
    fun label(lang: String): String = when (lang) {
        "ar" -> "%02d - %s".format(code, ar)
        "en" -> "%02d - %s".format(code, fr)
        else -> "%02d - %s".format(code, fr)
    }
}

class MainActivity : Activity() {
    private val wilayas = listOf(
        Wilaya(01, "Adrar", "أدرار"),
        Wilaya(02, "Chlef", "الشلف"),
        Wilaya(03, "Laghouat", "الأغواط"),
        Wilaya(04, "Oum El Bouaghi", "أم البواقي"),
        Wilaya(05, "Batna", "باتنة"),
        Wilaya(06, "Béjaïa", "بجاية"),
        Wilaya(07, "Biskra", "بسكرة"),
        Wilaya(08, "Béchar", "بشار"),
        Wilaya(09, "Blida", "البليدة"),
        Wilaya(10, "Bouira", "البويرة"),
        Wilaya(11, "Tamanrasset", "تمنراست"),
        Wilaya(12, "Tébessa", "تبسة"),
        Wilaya(13, "Tlemcen", "تلمسان"),
        Wilaya(14, "Tiaret", "تيارت"),
        Wilaya(15, "Tizi Ouzou", "تيزي وزو"),
        Wilaya(16, "Alger", "الجزائر"),
        Wilaya(17, "Djelfa", "الجلفة"),
        Wilaya(18, "Jijel", "جيجل"),
        Wilaya(19, "Sétif", "سطيف"),
        Wilaya(20, "Saïda", "سعيدة"),
        Wilaya(21, "Skikda", "سكيكدة"),
        Wilaya(22, "Sidi Bel Abbès", "سيدي بلعباس"),
        Wilaya(23, "Annaba", "عنابة"),
        Wilaya(24, "Guelma", "قالمة"),
        Wilaya(25, "Constantine", "قسنطينة"),
        Wilaya(26, "Médéa", "المدية"),
        Wilaya(27, "Mostaganem", "مستغانم"),
        Wilaya(28, "M'Sila", "المسيلة"),
        Wilaya(29, "Mascara", "معسكر"),
        Wilaya(30, "Ouargla", "ورقلة"),
        Wilaya(31, "Oran", "وهران"),
        Wilaya(32, "El Bayadh", "البيض"),
        Wilaya(33, "Illizi", "إليزي"),
        Wilaya(34, "Bordj Bou Arréridj", "برج بوعريريج"),
        Wilaya(35, "Boumerdès", "بومرداس"),
        Wilaya(36, "El Tarf", "الطارف"),
        Wilaya(37, "Tindouf", "تندوف"),
        Wilaya(38, "Tissemsilt", "تيسمسيلت"),
        Wilaya(39, "El Oued", "الوادي"),
        Wilaya(40, "Khenchela", "خنشلة"),
        Wilaya(41, "Souk Ahras", "سوق أهراس"),
        Wilaya(42, "Tipaza", "تيبازة"),
        Wilaya(43, "Mila", "ميلة"),
        Wilaya(44, "Aïn Defla", "عين الدفلى"),
        Wilaya(45, "Naâma", "النعامة"),
        Wilaya(46, "Aïn Témouchent", "عين تموشنت"),
        Wilaya(47, "Ghardaïa", "غرداية"),
        Wilaya(48, "Relizane", "غليزان"),
        Wilaya(49, "Timimoun", "تيميمون"),
        Wilaya(50, "Bordj Badji Mokhtar", "برج باجي مختار"),
        Wilaya(51, "Ouled Djellal", "أولاد جلال"),
        Wilaya(52, "Béni Abbès", "بني عباس"),
        Wilaya(53, "In Salah", "عين صالح"),
        Wilaya(54, "In Guezzam", "عين قزام"),
        Wilaya(55, "Touggourt", "تقرت"),
        Wilaya(56, "Djanet", "جانت"),
        Wilaya(57, "El M'Ghair", "المغير"),
        Wilaya(58, "El Meniaa", "المنيعة"),
        Wilaya(59, "Aflou", "أفلو"),
        Wilaya(60, "Barika", "بريكة"),
        Wilaya(61, "El Kantara", "القنطرة"),
        Wilaya(62, "Bir El Ater", "بئر العاتر"),
        Wilaya(63, "El Aricha", "العريشة"),
        Wilaya(64, "Ksar Chellala", "قصر الشلالة"),
        Wilaya(65, "Aïn Oussara", "عين وسارة"),
        Wilaya(66, "Messaad", "مسعد"),
        Wilaya(67, "Ksar El Boukhari", "قصر البخاري"),
        Wilaya(68, "Bou Saâda", "بوسعادة"),
        Wilaya(69, "El Abiodh Sidi Cheikh", "الأبيض سيدي الشيخ")
    )
    private var lang = "fr"
    private var selectedWilaya = 1
    private lateinit var root: LinearLayout
    private val dataFile = "transfo_manager_data.json"
    private var db = JSONObject()

    private fun tr(key: String): String {
        val all = mapOf(
            "fr" to mapOf(
                "language" to "Langue", "wilaya" to "Wilaya", "stations" to "Postes électriques",
                "addStation" to "Ajouter un poste", "noStations" to "Aucun poste dans cette wilaya.",
                "transformers" to "Transformateurs", "addTransformer" to "Ajouter un transformateur",
                "open" to "Ouvrir", "backup" to "Exporter la sauvegarde", "restore" to "Restaurer une sauvegarde",
                "stationName" to "Nom du poste", "transformerName" to "Nom du transformateur",
                "serial" to "Numéro de série", "power" to "Puissance (MVA)", "ratio" to "Rapport de tension",
                "save" to "Enregistrer", "cancel" to "Annuler", "tests" to "Essais",
                "addTest" to "Ajouter un résultat d'essai", "testName" to "Nom de l'essai",
                "value" to "Résultat", "unit" to "Unité", "empty" to "Veuillez saisir un nom.",
                "saved" to "Enregistré", "backupOk" to "Sauvegarde exportée.", "restoreOk" to "Données restaurées.",
                "badFile" to "Fichier invalide.", "delete" to "Supprimer", "none" to "Aucun transformateur.",
                "home" to "Accueil", "app" to "TRANSFO-MANAGER 360", "serialShort" to "N° série",
                "confirm" to "Confirmer la suppression ?", "testPresets" to "Essais courants",
                "noData" to "Aucune donnée"
            ),
            "ar" to mapOf(
                "language" to "اللغة", "wilaya" to "الولاية", "stations" to "المحطات الفرعية",
                "addStation" to "إضافة محطة فرعية", "noStations" to "ما كاين حتى محطة في هذي الولاية.",
                "transformers" to "المحوّلات", "addTransformer" to "إضافة محوّل",
                "open" to "فتح", "backup" to "تصدير نسخة احتياطية", "restore" to "استرجاع نسخة احتياطية",
                "stationName" to "اسم المحطة", "transformerName" to "اسم المحوّل",
                "serial" to "الرقم التسلسلي", "power" to "القدرة (MVA)", "ratio" to "نسبة الجهد",
                "save" to "حفظ", "cancel" to "إلغاء", "tests" to "الاختبارات",
                "addTest" to "إضافة نتيجة اختبار", "testName" to "اسم الاختبار",
                "value" to "النتيجة", "unit" to "الوحدة", "empty" to "يرجى إدخال الاسم.",
                "saved" to "تم الحفظ", "backupOk" to "تم تصدير النسخة الاحتياطية.",
                "restoreOk" to "تم استرجاع البيانات.", "badFile" to "الملف غير صالح.",
                "delete" to "حذف", "none" to "مازال ما كاين حتى محوّل.",
                "home" to "الرئيسية", "app" to "TRANSFO-MANAGER 360", "serialShort" to "الرقم التسلسلي",
                "confirm" to "تأكيد الحذف؟", "testPresets" to "اختبارات شائعة", "noData" to "لا توجد بيانات"
            ),
            "en" to mapOf(
                "language" to "Language", "wilaya" to "Wilaya", "stations" to "Substations",
                "addStation" to "Add substation", "noStations" to "No substations in this wilaya.",
                "transformers" to "Transformers", "addTransformer" to "Add transformer",
                "open" to "Open", "backup" to "Export backup", "restore" to "Restore backup",
                "stationName" to "Substation name", "transformerName" to "Transformer name",
                "serial" to "Serial number", "power" to "Power (MVA)", "ratio" to "Voltage ratio",
                "save" to "Save", "cancel" to "Cancel", "tests" to "Tests",
                "addTest" to "Add test result", "testName" to "Test name", "value" to "Result",
                "unit" to "Unit", "empty" to "Please enter a name.", "saved" to "Saved",
                "backupOk" to "Backup exported.", "restoreOk" to "Data restored.",
                "badFile" to "Invalid file.", "delete" to "Delete", "none" to "No transformers yet.",
                "home" to "Home", "app" to "TRANSFO-MANAGER 360", "serialShort" to "Serial",
                "confirm" to "Confirm deletion?", "testPresets" to "Common tests", "noData" to "No data"
            )
        )
        return all[lang]?.get(key) ?: key
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadDb()
        renderHome()
    }

    private fun loadDb() {
        db = try {
            JSONObject(openFileInput(dataFile).bufferedReader().use { it.readText() })
                .also { if (it.optJSONArray("stations") == null) it.put("stations", JSONArray()) }
        } catch (_: Exception) {
            JSONObject().put("version", 1).put("stations", JSONArray())
        }
    }

    private fun persist() {
        try {
            openFileOutput(dataFile, MODE_PRIVATE).use { it.write(db.toString(2).toByteArray(Charsets.UTF_8)) }
        } catch (e: Exception) { toast(e.message ?: "Save error") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun makeRoot(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(18))
            layoutDirection = if (lang == "ar") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        return root
    }

    private fun addText(parent: LinearLayout, text: String, size: Float = 16f, bold: Boolean = false) {
        parent.addView(TextView(this).apply {
            this.text = text; textSize = size
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(5))
        })
    }

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        parent.addView(Button(this).apply { this.text = text; setOnClickListener { action() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3); bottomMargin = dp(3) })
    }

    private fun renderHome() {
        val r = makeRoot()
        addText(r, tr("app"), 24f, true)
        addText(r, "Android • v1.0 • Local storage", 12f)
        addText(r, tr("language"), 14f, true)
        val langSpinner = Spinner(this)
        langSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Français", "العربية", "English"))
        langSpinner.setSelection(when (lang) { "ar" -> 1; "en" -> 2; else -> 0 })
        r.addView(langSpinner)
        langSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val newLang = listOf("fr", "ar", "en")[position]
                if (newLang != lang) { lang = newLang; renderHome() }
            }
        }
        addText(r, tr("wilaya"), 14f, true)
        val wSpinner = Spinner(this)
        wSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, wilayas.map { it.label(lang) })
        wSpinner.setSelection((selectedWilaya - 1).coerceIn(0, wilayas.size - 1))
        r.addView(wSpinner)
        r.addView(TextView(this).apply {
            text = "69 wilayas • 69 wilayas • 69 ولاية"
            textSize = 12f
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "station_list" }
        addText(r, tr("stations"), 20f, true)
        r.addView(list)
        renderStationsInto(list)
        wSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedWilaya = wilayas[position].code
                renderStationsInto(list)
            }
        }
        addButton(r, tr("addStation")) { stationDialog() }
        addButton(r, tr("backup")) { exportBackup() }
        addButton(r, tr("restore")) { importBackup() }
        addText(r, "Local-only data / Données locales / البيانات محفوظة في هذا الجهاز", 12f)
    }

    private fun renderStationsInto(container: LinearLayout) {
        container.removeAllViews()
        val stations = db.optJSONArray("stations") ?: JSONArray()
        var count = 0
        for (i in 0 until stations.length()) {
            val s = stations.optJSONObject(i) ?: continue
            if (s.optInt("wilayaCode") != selectedWilaya) continue
            count++
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(7), dp(8), dp(7)) }
            addText(card, s.optString("name"), 17f, true)
            val trs = s.optJSONArray("transformers") ?: JSONArray()
            addText(card, "${tr("transformers")}: ${trs.length()}", 13f)
            addButton(card, tr("open")) { stationDetail(s.optString("id")) }
            addButton(card, tr("delete")) { confirmDeleteStation(s.optString("id")) }
            container.addView(card)
            container.addView(View(this).apply { setBackgroundColor(0xFFE0E0E0.toInt()) },
                LinearLayout.LayoutParams(-1, dp(1)))
        }
        if (count == 0) addText(container, tr("noStations"), 14f)
    }

    private fun stationDialog() {
        val input = EditText(this).apply { hint = tr("stationName") }
        AlertDialog.Builder(this).setTitle(tr("addStation")).setView(input)
            .setPositiveButton(tr("save")) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isBlank()) { toast(tr("empty")); return@setPositiveButton }
                val arr = db.optJSONArray("stations") ?: JSONArray().also { db.put("stations", it) }
                arr.put(JSONObject().put("id", UUID.randomUUID().toString()).put("name", name)
                    .put("wilayaCode", selectedWilaya).put("transformers", JSONArray()))
                persist(); renderHome(); toast(tr("saved"))
            }.setNegativeButton(tr("cancel"), null).show()
    }

    private fun stationById(id: String): JSONObject? {
        val arr = db.optJSONArray("stations") ?: return null
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i)
            if (s?.optString("id") == id) return s
        }
        return null
    }

    private fun stationDetail(id: String) {
        val station = stationById(id) ?: return
        val r = makeRoot()
        addText(r, station.optString("name"), 23f, true)
        addText(r, wilayas.firstOrNull { it.code == station.optInt("wilayaCode") }?.label(lang) ?: "", 13f)
        addText(r, tr("transformers"), 20f, true)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(list)
        renderTransformers(station, list)
        addButton(r, tr("addTransformer")) { transformerDialog(id) }
        addButton(r, tr("home")) { renderHome() }
    }

    private fun renderTransformers(station: JSONObject, list: LinearLayout) {
        list.removeAllViews()
        val arr = station.optJSONArray("transformers") ?: JSONArray()
        if (arr.length() == 0) addText(list, tr("none"))
        for (i in 0 until arr.length()) {
            val trf = arr.optJSONObject(i) ?: continue
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
            addText(card, trf.optString("name"), 17f, true)
            addText(card, "${tr("serial")}: ${trf.optString("serial")} • ${tr("power")}: ${trf.optString("power")}", 13f)
            addText(card, "${tr("ratio")}: ${trf.optString("ratio")}", 13f)
            addButton(card, tr("tests")) { testsDialog(station.optString("id"), trf.optString("id")) }
            addButton(card, tr("delete")) { deleteTransformer(station.optString("id"), trf.optString("id")) }
            list.addView(card)
            list.addView(View(this).apply { setBackgroundColor(0xFFE0E0E0.toInt()) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun transformerDialog(stationId: String) {
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), 0) }
        val name = EditText(this).apply { hint = tr("transformerName") }
        val serial = EditText(this).apply { hint = tr("serial") }
        val power = EditText(this).apply { hint = tr("power"); inputType = 8194 }
        val ratio = EditText(this).apply { hint = tr("ratio") }
        fields.addView(name); fields.addView(serial); fields.addView(power); fields.addView(ratio)
        AlertDialog.Builder(this).setTitle(tr("addTransformer")).setView(fields)
            .setPositiveButton(tr("save")) { _, _ ->
                if (name.text.toString().trim().isBlank()) { toast(tr("empty")); return@setPositiveButton }
                val station = stationById(stationId) ?: return@setPositiveButton
                val arr = station.optJSONArray("transformers") ?: JSONArray().also { station.put("transformers", it) }
                arr.put(JSONObject().put("id", UUID.randomUUID().toString())
                    .put("name", name.text.toString().trim()).put("serial", serial.text.toString().trim())
                    .put("power", power.text.toString().trim()).put("ratio", ratio.text.toString().trim())
                    .put("tests", JSONArray()).put("maintenance", JSONArray()))
                persist(); stationDetail(stationId); toast(tr("saved"))
            }.setNegativeButton(tr("cancel"), null).show()
    }

    private fun transformerById(station: JSONObject, id: String): JSONObject? {
        val arr = station.optJSONArray("transformers") ?: return null
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i)
            if (item?.optString("id") == id) return item
        }
        return null
    }

    private fun testsDialog(stationId: String, transformerId: String) {
        val station = stationById(stationId) ?: return
        val trf = transformerById(station, transformerId) ?: return
        val tests = trf.optJSONArray("tests") ?: JSONArray().also { trf.put("tests", it) }
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), 0, dp(20), 0) }
        val presets = listOf(
            "Teneur en eau" to "mg/kg (ppm)",
            "Tension de claquage" to "kV",
            "Tangente delta traversée A" to "%",
            "Tangente delta traversée B" to "%",
            "Tangente delta traversée C" to "%",
            "DGA - H2" to "ppm", "DGA - CH4" to "ppm", "DGA - C2H2" to "ppm",
            "DGA - C2H4" to "ppm", "DGA - C2H6" to "ppm", "DGA - CO" to "ppm", "DGA - CO2" to "ppm",
            "Rapport de transformation (TTR)" to "", "Résistance des enroulements" to "µΩ",
            "Résistance d'isolement" to "MΩ", "Thermographie" to "°C"
        )
        val unit = EditText(this).apply { hint = tr("unit") }
        val testName = AutoCompleteTextView(this).apply {
            hint = tr("testName")
            setAdapter(ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, presets.map { it.first }))
            setOnItemClickListener { _, _, position, _ ->
                val found = presets[position]
                unit.setText(found.second)
            }
        }
        val value = EditText(this).apply { hint = tr("value") }
        fields.addView(testName); fields.addView(value); fields.addView(unit)
        addText(fields, tr("testPresets"), 12f)
        val summary = TextView(this).apply {
            text = (0 until tests.length()).mapNotNull { tests.optJSONObject(it) }
                .joinToString("\n") { "${it.optString("date")} • ${it.optString("name")}: ${it.optString("value")} ${it.optString("unit")}" }
                .ifBlank { tr("noData") }
            textSize = 13f
        }
        fields.addView(summary)
        AlertDialog.Builder(this).setTitle(tr("addTest")).setView(fields)
            .setPositiveButton(tr("save")) { _, _ ->
                val name = testName.text.toString().trim()
                if (name.isBlank()) { toast(tr("empty")); return@setPositiveButton }
                tests.put(JSONObject().put("id", UUID.randomUUID().toString()).put("name", name)
                    .put("value", value.text.toString().trim()).put("unit", unit.text.toString().trim())
                    .put("date", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())))
                persist(); toast(tr("saved"))
            }.setNegativeButton(tr("cancel"), null).show()
    }

    private fun deleteTransformer(stationId: String, transformerId: String) {
        val station = stationById(stationId) ?: return
        val arr = station.optJSONArray("transformers") ?: return
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.optString("id") != transformerId) out.put(item)
        }
        station.put("transformers", out); persist(); stationDetail(stationId)
    }

    private fun confirmDeleteStation(id: String) {
        AlertDialog.Builder(this).setTitle(tr("delete")).setMessage(tr("confirm"))
            .setPositiveButton(tr("delete")) { _, _ ->
                val old = db.optJSONArray("stations") ?: JSONArray()
                val out = JSONArray()
                for (i in 0 until old.length()) {
                    val item = old.optJSONObject(i) ?: continue
                    if (item.optString("id") != id) out.put(item)
                }
                db.put("stations", out); persist(); renderHome()
            }.setNegativeButton(tr("cancel"), null).show()
    }

    private fun exportBackup() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "transfo-manager-backup.json")
        }
        startActivityForResult(intent, 501)
    }

    private fun importBackup() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(intent, 502)
    }

    @Deprecated("Deprecated in Android, retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        try {
            val uri = data.data!!
            if (requestCode == 501) {
                contentResolver.openOutputStream(uri)?.use { it.write(db.toString(2).toByteArray(Charsets.UTF_8)) }
                toast(tr("backupOk"))
            } else if (requestCode == 502) {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val imported = JSONObject(text)
                if (imported.optJSONArray("stations") == null) throw Exception("Missing stations")
                db = imported; persist(); renderHome(); toast(tr("restoreOk"))
            }
        } catch (_: Exception) { toast(tr("badFile")) }
    }
}
